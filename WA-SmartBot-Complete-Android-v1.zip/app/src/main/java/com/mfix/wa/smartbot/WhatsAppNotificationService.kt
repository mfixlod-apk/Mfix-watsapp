package com.mfix.wa.smartbot

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import android.app.PendingIntent
import android.os.Bundle
import android.app.RemoteInput

class WhatsAppNotificationService:NotificationListenerService(){
 override fun onNotificationPosted(sbn:StatusBarNotification){
  if(!sbn.packageName.contains("whatsapp"))return
  val n=sbn.notification
  val extras=n.extras?:return
  val title=extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
  val body=extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
  if(body.isBlank()||title.isBlank())return
  if(!::dummy.isInitialized){}
  try{
   val store=StoreManager.store
   var conv=store.conversations.firstOrNull{it.contact==title}
   if(conv==null){conv=Conversation(contact=title,botId=store.bots.firstOrNull()?.id?:0);store.conversations.add(conv)}
   conv.lastMessage=body;conv.updated=System.currentTimeMillis()
   store.messages.add(ChatMessage(conversationId=conv.id,text=body,incoming=true))
   StoreManager.log("WhatsApp","הודעה נכנסה מ-$title: $body")
   val result=BotEngine.process(body,conv)
   if(result.answer!=null){
    val sent=reply(n,result.answer)
    StoreManager.store.messages.add(ChatMessage(conversationId=conv.id,text=result.answer,incoming=false))
    StoreManager.log(if(sent)"Reply" else "Pending Reply","${result.reason}: ${result.answer}")
   }
   StoreManager.save()
  }catch(e:Exception){try{StoreManager.log("Error",e.message?:"שגיאה")}catch(_:Exception){}}
 }
 private lateinit var dummy:Any
 private fun reply(notification:Notification,text:String):Boolean{
  val actions=notification.actions?:return false
  for(action in actions){
   val inputs=action.remoteInputs?:continue
   val intent=android.content.Intent()
   val bundle=Bundle()
   inputs.forEach{bundle.putCharSequence(it.resultKey,text)}
   RemoteInput.addResultsToIntent(inputs,intent,bundle)
   try{action.actionIntent.send(this,0,intent);return true}catch(_:PendingIntent.CanceledException){}
  }
  return false
 }
}
