package com.mfix.wa.smartbot
import android.content.Context
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

object StoreManager {
 private val json=Json{ignoreUnknownKeys=true;encodeDefaults=true}
 lateinit var store:AppStore
 private lateinit var ctx:Context
 fun init(context:Context){ctx=context.applicationContext;store=load()}
 fun load():AppStore {
  val s=ctx.getSharedPreferences("smartbot",Context.MODE_PRIVATE).getString("data",null)?:return AppStore()
  return try{json.decodeFromString<AppStore>(s)}catch(e:Exception){AppStore()}
 }
 fun save(){ctx.getSharedPreferences("smartbot",Context.MODE_PRIVATE).edit().putString("data",json.encodeToString(store)).apply()}
 fun log(type:String,msg:String){store.logs.add(0,LogEntry(type=type,message=msg));if(store.logs.size>500)store.logs.removeLast();save()}
}
