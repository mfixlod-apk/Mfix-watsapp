package com.mfix.wa.smartbot

object BotEngine {
 data class Result(val answer:String?,val bot:Bot?,val reason:String)
 fun process(text:String, conversation:Conversation):Result{
  if(conversation.human)return Result(null,null,"שיחה אצל נציג")
  val bot=StoreManager.store.bots.firstOrNull{it.id==conversation.botId && it.enabled}
      ?:StoreManager.store.bots.firstOrNull{it.enabled}
      ?:return Result(null,null,"אין בוט פעיל")
  val q=text.trim().lowercase()
  val rule=bot.rules.firstOrNull{it.enabled && it.trigger.isNotBlank() && q.contains(it.trigger.lowercase())}
  if(rule!=null)return Result(rule.answer,bot,"חוק: ${rule.trigger}")
  val knowledge=bot.knowledge.firstOrNull{line ->
    line.split(" ").any{w->w.length>3 && q.contains(w.lowercase())}
  }
  if(knowledge!=null)return Result(knowledge,bot,"מאגר ידע")
  return if(bot.fallback.isNotBlank()) Result(bot.fallback,bot,"תשובת ברירת מחדל")
  else Result(null,bot,"אין תשובה")
 }
}
