package com.mfix.wa.smartbot

import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.graphics.Color
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity:AppCompatActivity(){
 private lateinit var page:LinearLayout
 private val bg=Color.rgb(18,20,24); private val card=Color.rgb(35,39,46); private val green=Color.rgb(37,211,102)
 private val white=Color.WHITE; private val gray=Color.rgb(185,190,195)

 override fun onCreate(b:Bundle?){super.onCreate(b);StoreManager.init(this);dashboard()}
 override fun onPause(){super.onPause();StoreManager.save()}

 private fun screen(title:String,sub:String=""){
  val scroll=ScrollView(this);page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,42,28,28);setBackgroundColor(bg)}
  scroll.addView(page);setContentView(scroll);label(title,28,true);if(sub.isNotBlank())label(sub,14)
 }
 private fun label(s:String,size:Float=16f,bold:Boolean=false){page.addView(TextView(this).apply{text=s;textSize=size;setTextColor(if(bold)white else gray);if(bold)setTypeface(null,1);setPadding(2,4,2,12)})}
 private fun button(s:String,fn:()->Unit){page.addView(MaterialButton(this).apply{text=s;setTextColor(white);setBackgroundColor(green);setOnClickListener{fn()}},LinearLayout.LayoutParams(-1,54).apply{bottomMargin=9})}
 private fun back(s:String,fn:()->Unit){page.addView(Button(this).apply{text=s;setOnClickListener{fn()}},LinearLayout.LayoutParams(-1,50).apply{bottomMargin=7})}
 private fun input(h:String,multi:Boolean=false):EditText{val e=EditText(this).apply{hint=h;setHintTextColor(Color.GRAY);setTextColor(white);setBackgroundColor(card);setPadding(18,10,18,10);if(multi){minLines=3;gravity=android.view.Gravity.TOP}else setSingleLine(true)};page.addView(e,LinearLayout.LayoutParams(-1,if(multi)-2 else 55).apply{bottomMargin=9});return e}
 private fun item(a:String,b:String,fn:()->Unit){val x=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,15,18,15);setBackgroundColor(card);setOnClickListener{fn()}};x.addView(TextView(this).apply{text=a;textSize=18f;setTextColor(white);setTypeface(null,1)});x.addView(TextView(this).apply{text=b;textSize=13f;setTextColor(gray)});page.addView(x,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=9})}

 private fun dashboard(){
  val s=StoreManager.store;screen("WA SmartBot","מערכת ניהול בוט WhatsApp")
  item("🟢 WhatsApp","חיבור והרשאות"){whatsapp()}
  item("🤖 בוטים","${s.bots.size} בוטים • ${s.bots.count{it.enabled}} פעילים"){bots()}
  item("💬 שיחות","${s.conversations.size} שיחות"){conversations()}
  item("👥 CRM / לידים","${s.leads.size} לקוחות"){leads()}
  item("⚡ אוטומציות","${s.automations.size} אוטומציות"){automations()}
  item("📝 תבניות","${s.templates.size} תבניות"){templates()}
  item("📊 אנליטיקה","נתוני פעילות"){analytics()}
  item("📜 לוג פעילות","${s.logs.size} אירועים"){logs()}
  back("⚙️ הגדרות וגיבוי"){settings()}
 }

 private fun whatsapp(){
  screen("חיבור WhatsApp","המכשיר הזה צריך להיות עם WhatsApp מותקן")
  val enabled=Settings.Secure.getString(contentResolver,"enabled_notification_listeners")?.contains(packageName)==true
  label(if(enabled)"🟢 Notification Access פעיל" else "🔴 Notification Access לא פעיל",18,true)
  button("פתח הרשאת התראות"){startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))}
  label("לאחר אישור ההרשאה, WA SmartBot יכול לקלוט התראות WhatsApp. מענה אוטומטי נשלח רק אם ההתראה מספקת פעולת Reply תואמת.")
  back("חזרה"){dashboard()}
 }

 private fun bots(){
  screen("הבוטים שלי","יצירה וניהול מלא")
  button("＋ צור בוט"){botEditor(null)}
  StoreManager.store.bots.forEach{b->item("🤖 ${b.name} ${if(b.enabled)"●" else "○"}","${b.rules.size} חוקים • ${b.knowledge.size} ידע • ${b.flows.size} Flow"){botManager(b)}}
  back("חזרה"){dashboard()}
 }
 private fun botEditor(old:Bot?){
  val fresh=old==null;val b=old?:Bot();screen(if(fresh)"בוט חדש" else "עריכת בוט")
  val name=input("שם הבוט").apply{setText(b.name)}
  val role=input("תפקיד הבוט",true).apply{setText(b.role)}
  val ins=input("הוראות מפורטות לבוט",true).apply{setText(b.instructions)}
  val greet=input("הודעת פתיחה",true).apply{setText(b.greeting)}
  val fallback=input("תשובת ברירת מחדל",true).apply{setText(b.fallback)}
  button("שמור"){b.name=name.text.toString();b.role=role.text.toString();b.instructions=ins.text.toString();b.greeting=greet.text.toString();b.fallback=fallback.text.toString();if(fresh)StoreManager.store.bots.add(b);StoreManager.save();botManager(b)}
  back("ביטול"){bots()}
 }
 private fun botManager(b:Bot){
  screen("🤖 ${b.name}","מנהל הבוט")
  item("🧠 הגדרות וזהות","תפקיד והוראות"){botEditor(b)}
  item("⚡ חוקים","${b.rules.size} תגובות"){rules(b)}
  item("📚 מאגר ידע","${b.knowledge.size} פריטים"){knowledge(b)}
  item("🔀 Flow Builder","${b.flows.size} שלבים"){flows(b)}
  item("🧪 בדיקת בוט","סימולציה"){test(b)}
  button(if(b.enabled)"כבה בוט" else "הפעל בוט"){b.enabled=!b.enabled;StoreManager.save();botManager(b)}
  back("חזרה"){bots()}
 }

 private fun rules(b:Bot){screen("חוקים","אם הלקוח כותב X → תשובה Y");button("＋ כלל"){ruleEdit(b,null)}
  b.rules.forEachIndexed{i,r->item("אם: ${r.trigger}","תשובה: ${r.answer.take(70)}"){ruleEdit(b,i)}};back("חזרה"){botManager(b)}}
 private fun ruleEdit(b:Bot,i:Int?){val r=i?.let{b.rules[it]}?:Rule();screen("עריכת כלל");val a=input("מילה/משפט").apply{setText(r.trigger)};val c=input("תשובה",true).apply{setText(r.answer)}
  button("שמור"){r.trigger=a.text.toString();r.answer=c.text.toString();if(i==null)b.rules.add(r);StoreManager.save();rules(b)}
  if(i!=null)back("מחק"){b.rules.removeAt(i);StoreManager.save();rules(b)};back("חזרה"){rules(b)}}

 private fun knowledge(b:Bot){screen("מאגר ידע","מידע שהבוט יכול להשתמש בו");button("＋ הוסף מידע"){knowledgeEdit(b,null)}
  b.knowledge.forEachIndexed{i,x->item(x.take(80),"לחץ לעריכה"){knowledgeEdit(b,i)}};back("חזרה"){botManager(b)}}
 private fun knowledgeEdit(b:Bot,i:Int?){screen("עריכת ידע");val old=i?.let{b.knowledge[it]}?:"";val e=input("מידע",true).apply{setText(old)}
  button("שמור"){if(i==null)b.knowledge.add(e.text.toString())else b.knowledge[i]=e.text.toString();StoreManager.save();knowledge(b)}
  if(i!=null)back("מחק"){b.knowledge.removeAt(i);StoreManager.save();knowledge(b)};back("חזרה"){knowledge(b)}}

 private fun flows(b:Bot){screen("Flow Builder","שלבים והסתעפויות בסיסיים");button("＋ שלב חדש"){flowEdit(b,null)}
  b.flows.forEachIndexed{i,f->item(f.title, f.question){flowEdit(b,i)}};back("חזרה"){botManager(b)}}
 private fun flowEdit(b:Bot,i:Int?){val f=i?.let{b.flows[it]}?:FlowStep();screen("שלב Flow");val a=input("שם השלב").apply{setText(f.title)};val q=input("שאלה ללקוח",true).apply{setText(f.question)};val ex=input("תשובה צפויה/תנאי").apply{setText(f.expected)};val nx=input("השלב הבא").apply{setText(f.next)}
  button("שמור"){f.title=a.text.toString();f.question=q.text.toString();f.expected=ex.text.toString();f.next=nx.text.toString();if(i==null)b.flows.add(f);StoreManager.save();flows(b)}
  if(i!=null)back("מחק"){b.flows.removeAt(i);StoreManager.save();flows(b)};back("חזרה"){flows(b)}}

 private fun test(b:Bot){screen("בדיקת בוט","בדיקה מקומית");val e=input("הודעת לקוח",true);val out=TextView(this).apply{text="התשובה תופיע כאן";textSize=18f;setTextColor(white);setPadding(18,22,18,22);setBackgroundColor(card)};page.addView(out,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=10})
  button("בדוק"){val c=Conversation(botId=b.id);val r=BotEngine.process(e.text.toString(),c);out.text=r.answer?:"אין תשובה (${r.reason})"};back("חזרה"){botManager(b)}}

 private fun conversations(){screen("שיחות","שיחות שנקלטו מהמכשיר");if(StoreManager.store.conversations.isEmpty())label("עדיין אין שיחות.")
  StoreManager.store.conversations.sortedByDescending{it.updated}.forEach{c->item(c.contact,c.lastMessage){conversation(c)}};back("חזרה"){dashboard()}}
 private fun conversation(c:Conversation){screen("💬 ${c.contact}",if(c.human)"נציג אנושי" else "בוט פעיל")
  StoreManager.store.messages.filter{it.conversationId==c.id}.forEach{m->label((if(m.incoming)"👤 " else "🤖 ")+m.text,16,m.incoming)}
  button(if(c.human)"החזר לבוט" else "העבר לנציג"){c.human=!c.human;StoreManager.save();conversation(c)}
  back("חזרה"){conversations()}}

 private fun leads(){screen("CRM / לידים","לקוחות ומעקב");button("＋ ליד חדש"){leadEdit(null)}
  StoreManager.store.leads.forEach{l->item("👤 ${l.name}","${l.phone} • ${l.status}"){leadEdit(l)}};back("חזרה"){dashboard()}}
 private fun leadEdit(old:Lead?){val fresh=old==null;val l=old?:Lead();screen("עריכת ליד");val n=input("שם").apply{setText(l.name)};val p=input("טלפון").apply{setText(l.phone)};val st=input("סטטוס").apply{setText(l.status)};val tg=input("תגיות").apply{setText(l.tags)};val note=input("הערות",true).apply{setText(l.note)}
  button("שמור"){l.name=n.text.toString();l.phone=p.text.toString();l.status=st.text.toString();l.tags=tg.text.toString();l.note=note.text.toString();if(fresh)StoreManager.store.leads.add(l);StoreManager.save();leads()}
  if(!fresh)back("מחק"){StoreManager.store.leads.remove(l);StoreManager.save();leads()};back("חזרה"){leads()}}

 private fun automations(){screen("אוטומציות","טריגרים ופעולות");button("＋ אוטומציה"){automationEdit(null)}
  StoreManager.store.automations.forEach{a->item("⚡ ${a.name}", "${a.trigger} → ${a.action}"){automationEdit(a)}};back("חזרה"){dashboard()}}
 private fun automationEdit(old:Automation?){val fresh=old==null;val a=old?:Automation();screen("אוטומציה");val n=input("שם").apply{setText(a.name)};val t=input("טריגר").apply{setText(a.trigger)};val ac=input("פעולה",true).apply{setText(a.action)}
  button("שמור"){a.name=n.text.toString();a.trigger=t.text.toString();a.action=ac.text.toString();if(fresh)StoreManager.store.automations.add(a);StoreManager.save();automations()}
  if(!fresh)back("מחק"){StoreManager.store.automations.remove(a);StoreManager.save();automations()};back("חזרה"){automations()}}

 private fun templates(){screen("תבניות הודעה","תשובות מוכנות");button("＋ תבנית"){templateEdit(null)}
  StoreManager.store.templates.forEach{t->item(t.title,t.body.take(70)){templateEdit(t)}};back("חזרה"){dashboard()}}
 private fun templateEdit(old:Template?){val fresh=old==null;val t=old?:Template();screen("תבנית");val n=input("שם").apply{setText(t.title)};val b=input("תוכן",true).apply{setText(t.body)}
  button("שמור"){t.title=n.text.toString();t.body=b.text.toString();if(fresh)StoreManager.store.templates.add(t);StoreManager.save();templates()}
  if(!fresh)back("מחק"){StoreManager.store.templates.remove(t);StoreManager.save();templates()};back("חזרה"){templates()}}

 private fun analytics(){val s=StoreManager.store;screen("אנליטיקה","נתוני המכשיר");label("בוטים: ${s.bots.size}",20,true);label("בוטים פעילים: ${s.bots.count{it.enabled}}");label("שיחות: ${s.conversations.size}");label("הודעות: ${s.messages.size}");label("לידים: ${s.leads.size}");label("חוקים: ${s.bots.sumOf{it.rules.size}}");back("חזרה"){dashboard()}}
 private fun logs(){screen("לוג פעילות","אירועי מערכת");StoreManager.store.logs.forEach{l->item(l.type,l.message){}};back("חזרה"){dashboard()}}
 private fun settings(){screen("הגדרות","נתונים וגיבוי מקומי");button("שמור נתונים"){StoreManager.save();Toast.makeText(this,"נשמר",Toast.LENGTH_SHORT).show()};label("הנתונים נשמרים מקומית במכשיר.");back("חזרה"){dashboard()}}
}
