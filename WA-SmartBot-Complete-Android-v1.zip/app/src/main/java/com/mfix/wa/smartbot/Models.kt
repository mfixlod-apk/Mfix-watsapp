package com.mfix.wa.smartbot

import kotlinx.serialization.Serializable

@Serializable data class Bot(
 var id:Long=System.currentTimeMillis(),
 var name:String="", var enabled:Boolean=true,
 var role:String="", var instructions:String="",
 var greeting:String="", var fallback:String="",
 var rules:MutableList<Rule> = mutableListOf(),
 var knowledge:MutableList<String> = mutableListOf(),
 var flows:MutableList<FlowStep> = mutableListOf()
)
@Serializable data class Rule(var id:Long=System.currentTimeMillis(),var trigger:String="",var answer:String="",var enabled:Boolean=true)
@Serializable data class FlowStep(var id:Long=System.currentTimeMillis(),var title:String="",var question:String="",var expected:String="",var next:String="")
@Serializable data class Lead(var id:Long=System.currentTimeMillis(),var name:String="",var phone:String="",var status:String="חדש",var tags:String="",var note:String="")
@Serializable data class Conversation(var id:Long=System.currentTimeMillis(),var contact:String="",var lastMessage:String="",var botId:Long=0,var human:Boolean=false,var updated:Long=System.currentTimeMillis())
@Serializable data class ChatMessage(var id:Long=System.currentTimeMillis(),var conversationId:Long=0,var text:String="",var incoming:Boolean=true,var time:Long=System.currentTimeMillis())
@Serializable data class Template(var id:Long=System.currentTimeMillis(),var title:String="",var body:String="")
@Serializable data class Automation(var id:Long=System.currentTimeMillis(),var name:String="",var trigger:String="",var action:String="",var enabled:Boolean=true)
@Serializable data class LogEntry(var id:Long=System.currentTimeMillis(),var time:Long=System.currentTimeMillis(),var type:String="",var message:String="")
@Serializable data class AppStore(
 var bots:MutableList<Bot> = mutableListOf(),
 var leads:MutableList<Lead> = mutableListOf(),
 var conversations:MutableList<Conversation> = mutableListOf(),
 var messages:MutableList<ChatMessage> = mutableListOf(),
 var templates:MutableList<Template> = mutableListOf(),
 var automations:MutableList<Automation> = mutableListOf(),
 var logs:MutableList<LogEntry> = mutableListOf()
)
