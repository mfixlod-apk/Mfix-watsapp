plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="com.mfix.wa.smartbot"
    compileSdk=35
    defaultConfig {
        applicationId="com.mfix.wa.smartbot"
        minSdk=26
        targetSdk=35
        versionCode=100
        versionName="1.0.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
}
