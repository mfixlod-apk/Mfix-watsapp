# WA SmartBot Complete Android

מערכת מקומית לניהול בוטים, שיחות, לידים, ידע, חוקים ואוטומציות.

## WhatsApp
האפליקציה כוללת NotificationListenerService לקליטת התראות WhatsApp כאשר המשתמש מעניק הרשאת Notification Access.
מענה אוטומטי משתמש רק בפעולת RemoteInput/Reply שההתראה חושפת. אם אין פעולת Reply זמינה, המערכת מתעדת את ההודעה ולא טוענת שנשלחה תגובה.

## כלול
Dashboard, Bots, Knowledge, Rules, Flows, Conversations, CRM, Templates, Automations, Analytics, Logs, Settings.
